import random

print("Atinas Games Limited 2022-2023 PopularGamesForPython")
print("Title: Rock Paper Scissors")
print("Enjoy!")
KeyRegistery = input("Press Any Key To Continue")
print("=============================================")
def play_game():
    options = ["rock", "paper", "scissors"]
    computer_choice = random.choice(options)
    user_choice = input("Enter your choice (rock, paper, scissors): ")
    print(f"\nYou chose {user_choice}, and the computer chose {computer_choice}.\n")
    if user_choice == computer_choice:
        print("It's a tie!")
        keyRegistery = input("Press Any Key To Exit")
        exit()
    elif user_choice == "rock":
        if computer_choice == "scissors":
            print("You win!")
            keyRegistery = input("Press Any Key To Exit")
            exit()
        else:
            print("Computer wins!")
            keyRegistery = input("Press Any Key To Exit")
            exit()
    elif user_choice == "paper":
        if computer_choice == "rock":
            print("You win!")
            keyRegistery = input("Press Any Key To Exit")
            exit()
        else:
            print("Computer wins!")
            keyRegistery = input("Press Any Key To Exit")
            exit()
    elif user_choice == "scissors":
        if computer_choice == "paper":
            print("You win!")
            keyRegistery = input("Press Any Key To Exit")
            exit()
        else:
            print("Computer wins!")
            keyRegistery = input("Press Any Key To Exit")
            exit()

play_game()
