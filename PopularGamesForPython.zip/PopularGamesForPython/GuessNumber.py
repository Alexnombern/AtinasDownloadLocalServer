import random
print("Welcome To Guess The Number Game")
print("You Need To Guess Number 1 to 100")
print("To Win The Game You Need To Reach Level 41")
def guess_the_number():
    number = random.randint(1, 100)
    guess = 0
    level = 1
    while guess != number:
        guess = int(input("Guess a number between 1 and 100: "))
        if guess > number:
            print("Too high! Try again.")
        elif guess < number:
            print("Too low! Try again.")
        level += 1
        if level == 41:
            print("Congratulations! You have reached level 41 and won the game!")
            KeyRegistery = input("Press Key To Continue")
            break
    if level != 41:
        print("Congratulations! You guessed the number correctly.")
        KeyRegistery = input("Press Key To Continue")

guess_the_number()
